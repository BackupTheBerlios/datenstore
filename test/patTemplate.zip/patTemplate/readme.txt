patTemplate - powerful template engine

Copyright (c) 2001 by Stephan Schmidt <schst@php-tools.de>
download at http://www.php-tools.de

This program and all associated files are released under the GNU Lesser Public License,
see lgpl.txt for details!
